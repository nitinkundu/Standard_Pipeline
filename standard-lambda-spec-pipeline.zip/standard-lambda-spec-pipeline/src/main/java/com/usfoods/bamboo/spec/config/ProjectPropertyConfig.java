package com.usfoods.bamboo.spec.config;

public class ProjectPropertyConfig {
	
	private String bambooKey;
    
	private String bambooDescription;
    
	private String bambooName;
	
	private String bambooHostname;
	
	private String rootName;
	
	private String projectEnv;
    
    public ProjectPropertyConfig projectProperty(){
    	ProjectPropertyConfig projectProperty = new ProjectPropertyConfig();
		return projectProperty;
    }

	public String getBambooKey() {
		return bambooKey;
	}

	public String getBambooDescription() {
		return bambooDescription;
	}

	public String getBambooName() {
		return bambooName;
	}

	public void setBambooKey(String bambooKey) {
		this.bambooKey = bambooKey;
	}

	public void setBambooDescription(String bambooDescription) {
		this.bambooDescription = bambooDescription;
	}

	public void setBambooName(String bambooName) {
		this.bambooName = bambooName;
	}

	public String getBambooHostname() {
		return bambooHostname;
	}

	public void setBambooHostname(String bambooHostname) {
		this.bambooHostname = bambooHostname;
	}

	public String getRootName() {
		return rootName;
	}

	public void setRootName(String rootName) {
		this.rootName = rootName;
	}

	public String getProjectEnv() {
		return projectEnv;
	}

	public void setProjectEnv(String projectEnv) {
		this.projectEnv = projectEnv;
	}

	
}
