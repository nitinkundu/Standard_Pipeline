package com.usfoods.bamboo.spec.config;

public class UploadEnvVariableJobPropertyConfig {

	private String jobType;
	
	private String jobName;

	private String jobKey;
	
	private String artifactName;
	
	private String copyPattern;
	
	private Boolean sharable;
	
	private String artifactNameDev;
	
	private String copyPatternDev;
	
	private Boolean sharableDev;
	
	private String artifactNameSit;
	
	private String copyPatternSit;
	
	private Boolean sharableSit;
	
	private String artifactNameUat;
	
	private String copyPatternUat;
	
	private Boolean sharableUat;
	
	private String artifactNameQa;
	
	private String copyPatternQa;
	
	private Boolean sharableQa;
	
	private String artifactNamePerf;
	
	private String copyPatternPerf;
	
	private Boolean sharablePerf;
	
	private String artifactNameNonprod;
	
	private String copyPatternNonprod;
	
	private Boolean sharableNonprod;
	
	private String artifactNameProd;
	
	private String copyPatternProd;
	
	private Boolean sharableProd;
	
    public UploadEnvVariableJobPropertyConfig uploadEnvVariableJobPropertyConfig(){
    	UploadEnvVariableJobPropertyConfig uploadEnvVariableJobPropertyConfig = new UploadEnvVariableJobPropertyConfig();
		return uploadEnvVariableJobPropertyConfig;
    }

	public String getJobType() {
		return jobType;
	}

	public String getJobName() {
		return jobName;
	}

	public String getJobKey() {
		return jobKey;
	}

	public String getArtifactName() {
		return artifactName;
	}

	public String getCopyPattern() {
		return copyPattern;
	}

	public Boolean getSharable() {
		return sharable;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public void setArtifactName(String artifactName) {
		this.artifactName = artifactName;
	}

	public void setCopyPattern(String copyPattern) {
		this.copyPattern = copyPattern;
	}

	public void setSharable(Boolean sharable) {
		this.sharable = sharable;
	}

	public String getArtifactNameDev() {
		return artifactNameDev;
	}

	public void setArtifactNameDev(String artifactNameDev) {
		this.artifactNameDev = artifactNameDev;
	}

	public String getCopyPatternDev() {
		return copyPatternDev;
	}

	public void setCopyPatternDev(String copyPatternDev) {
		this.copyPatternDev = copyPatternDev;
	}

	public Boolean getSharableDev() {
		return sharableDev;
	}

	public void setSharableDev(Boolean sharableDev) {
		this.sharableDev = sharableDev;
	}

	public String getArtifactNameSit() {
		return artifactNameSit;
	}

	public void setArtifactNameSit(String artifactNameSit) {
		this.artifactNameSit = artifactNameSit;
	}

	public String getCopyPatternSit() {
		return copyPatternSit;
	}

	public void setCopyPatternSit(String copyPatternSit) {
		this.copyPatternSit = copyPatternSit;
	}

	public Boolean getSharableSit() {
		return sharableSit;
	}

	public void setSharableSit(Boolean sharableSit) {
		this.sharableSit = sharableSit;
	}

	public String getArtifactNameUat() {
		return artifactNameUat;
	}

	public void setArtifactNameUat(String artifactNameUat) {
		this.artifactNameUat = artifactNameUat;
	}

	public String getCopyPatternUat() {
		return copyPatternUat;
	}

	public void setCopyPatternUat(String copyPatternUat) {
		this.copyPatternUat = copyPatternUat;
	}

	public Boolean getSharableUat() {
		return sharableUat;
	}

	public void setSharableUat(Boolean sharableUat) {
		this.sharableUat = sharableUat;
	}

	public String getArtifactNameProd() {
		return artifactNameProd;
	}

	public void setArtifactNameProd(String artifactNameProd) {
		this.artifactNameProd = artifactNameProd;
	}

	public String getCopyPatternProd() {
		return copyPatternProd;
	}

	public void setCopyPatternProd(String copyPatternProd) {
		this.copyPatternProd = copyPatternProd;
	}

	public Boolean getSharableProd() {
		return sharableProd;
	}

	public void setSharableProd(Boolean sharableProd) {
		this.sharableProd = sharableProd;
	}

	public String getArtifactNameQa() {
		return artifactNameQa;
	}

	public void setArtifactNameQa(String artifactNameQa) {
		this.artifactNameQa = artifactNameQa;
	}

	public String getCopyPatternQa() {
		return copyPatternQa;
	}

	public void setCopyPatternQa(String copyPatternQa) {
		this.copyPatternQa = copyPatternQa;
	}

	public Boolean getSharableQa() {
		return sharableQa;
	}

	public void setSharableQa(Boolean sharableQa) {
		this.sharableQa = sharableQa;
	}

	public String getArtifactNameNonprod() {
		return artifactNameNonprod;
	}

	public void setArtifactNameNonprod(String artifactNameNonprod) {
		this.artifactNameNonprod = artifactNameNonprod;
	}

	public String getCopyPatternNonprod() {
		return copyPatternNonprod;
	}

	public void setCopyPatternNonprod(String copyPatternNonprod) {
		this.copyPatternNonprod = copyPatternNonprod;
	}

	public Boolean getSharableNonprod() {
		return sharableNonprod;
	}

	public void setSharableNonprod(Boolean sharableNonprod) {
		this.sharableNonprod = sharableNonprod;
	}

	public String getArtifactNamePerf() {
		return artifactNamePerf;
	}

	public void setArtifactNamePerf(String artifactNamePerf) {
		this.artifactNamePerf = artifactNamePerf;
	}

	public String getCopyPatternPerf() {
		return copyPatternPerf;
	}

	public void setCopyPatternPerf(String copyPatternPerf) {
		this.copyPatternPerf = copyPatternPerf;
	}

	public Boolean getSharablePerf() {
		return sharablePerf;
	}

	public void setSharablePerf(Boolean sharablePerf) {
		this.sharablePerf = sharablePerf;
	}
	
	
	
}
