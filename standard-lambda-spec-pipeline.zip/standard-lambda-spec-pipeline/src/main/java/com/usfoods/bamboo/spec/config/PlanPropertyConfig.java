package com.usfoods.bamboo.spec.config;

public class PlanPropertyConfig {
	
	private String bambooKey;
    
	private String bambooDescription;
    
	private String bambooName;

    public PlanPropertyConfig planPropertyConfig(){
    	return new PlanPropertyConfig();
    }

	public String getBambooKey() {
		return bambooKey;
	}

	public String getBambooDescription() {
		return bambooDescription;
	}

	public String getBambooName() {
		return bambooName;
	}

	public void setBambooKey(String bambooKey) {
		this.bambooKey = bambooKey;
	}

	public void setBambooDescription(String bambooDescription) {
		this.bambooDescription = bambooDescription;
	}

	public void setBambooName(String bambooName) {
		this.bambooName = bambooName;
	}
}
