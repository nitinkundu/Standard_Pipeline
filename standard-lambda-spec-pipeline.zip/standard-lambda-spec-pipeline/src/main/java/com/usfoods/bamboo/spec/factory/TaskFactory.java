package com.usfoods.bamboo.spec.factory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.usfoods.bamboo.spec.task.facade.TaskFacade;

public class TaskFactory {

	public static Task generateTaskFromExistingTaskWarehouse(String className) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException{
		TaskFacade jobFacade = generateStoreInstance(className);
		Task task = jobFacade.getTask();
		return task;
	}
	
	public static Task generateTaskFromExistingTaskWarehouse(String className, String fileName) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException{
		TaskFacade jobFacade = generateStoreInstance(className, fileName);
		Task task = jobFacade.getTask();
		return task;
	}
	
	private static TaskFacade generateStoreInstance(String className) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException{
		Class<?> clazz = Class.forName(className);
		Constructor<?> ctor = clazz.getConstructor();
		return (TaskFacade)ctor.newInstance();
	}

	private static TaskFacade generateStoreInstance(String className, String fileName) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException{
		Class<?> clazz = Class.forName(className);
		Constructor<?> ctor = clazz.getConstructor(String.class);
		return (TaskFacade)ctor.newInstance(fileName);
	}
	
}
