package com.usfoods.bamboo.spec.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.maven.model.Dependency;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.usfoods.bamboo.spec.config.Configuration;

public class Util {

	//retrieve the pipeline version
	public synchronized static String getPipelineVersion() {
	    String version = null;

	    // try to load from maven properties first
	    try {
	        Properties p = new Properties();
	        InputStream is = Util.class.getClassLoader().getResourceAsStream("pom.properties");

	        if (is != null) {
	            p.load(is);
	            version = p.getProperty("version", "");
	        }
	    } catch (Exception e) {
	        // ignore
	    	e.printStackTrace();
	    }

	    // fallback to using Java API
	    if (version == null) {
	        Package aPackage = Util.class.getPackage();
	        if (aPackage != null) {
	            version = aPackage.getImplementationVersion();
	            if (version == null) {
	                version = aPackage.getSpecificationVersion();
	            }
	        }
	    }

	    if (version == null) {
	        // we could not compute the version so use a blank
	        version = "";
	    }

	    return version;
	}
	
	//retrieve all dependency jar file version
	public static List<Variable> mavenPropertyReader() throws IOException, XmlPullParserException{
		
	    List<Variable> variableList = new ArrayList<Variable>();
		MavenXpp3Reader reader = new MavenXpp3Reader();
	    Model model;
	    InputStream is = Util.class.getClassLoader().getResourceAsStream("pom.xml");
	    model = reader.read(is);
	    List<Dependency> dependencyList = model.getDependencies();
	    for(Dependency d : dependencyList){
	    	String key = "bamboo.pipeline.dependency.jar." + d.getArtifactId() + ".version";
	    	String value = d.getVersion();
	    	if(key != null && value != null){
		    	Variable v = new Variable(key, value);
		    	variableList.add(v);
	    	}
	    }
	    return variableList;
	}
	
	public static DeploymentPermissions getDeploymentPermission(String fileName, String envKey, String deploymentProjectName){
		
		//logic to get permission for create stack dev
		String countKey = "deployment.user.permission." + envKey + ".count";
		String count = getPropertyByKey(countKey, fileName);
		Permissions permissions = new Permissions();
		for(int i = 1; i <= Integer.valueOf(count); i++){
			String key = "deployment.user.permission." + envKey + "." + i;
			String permission = getPropertyByKey(key, fileName);
			String[] permissionArr = permission.split("\\|");
			String user = permissionArr[0];
			List<PermissionType> permissionTypeList = new ArrayList<PermissionType>();
			for(int j = 1; j < permissionArr.length; j++){
				if(permissionArr[j].equals("VIEW")){
					permissionTypeList.add(PermissionType.VIEW);
				}else if(permissionArr[j].equals("EDIT")){
					permissionTypeList.add(PermissionType.EDIT);
				}else if(permissionArr[j].equals("ADMIN")){
					permissionTypeList.add(PermissionType.ADMIN);
				}else if(permissionArr[j].equals("BUILD")){
					permissionTypeList.add(PermissionType.BUILD);
				}else if(permissionArr[j].equals("CLONE")){
					permissionTypeList.add(PermissionType.CLONE);
				}else if(permissionArr[j].equals("CREATE")){
					permissionTypeList.add(PermissionType.CREATE);
				}else if(permissionArr[j].equals("DELETE")){
					permissionTypeList.add(PermissionType.DELETE);
				}
			}
			PermissionType[] permissionTypeArr = permissionTypeList.toArray(new PermissionType[permissionTypeList.size() - 1]);
			permissions = permissions.userPermissions(user, permissionTypeArr);
			
		}
		
		String loggedInUserpermission = getPropertyByKey("deployment.login.user.permission." + envKey, fileName);
		String[] loggedInUserpermissionArr = loggedInUserpermission.split("\\|");
		List<PermissionType> loggedInUserpermissionTypeList = new ArrayList<PermissionType>();
		for(String s: loggedInUserpermissionArr){
			if(s.equals("VIEW")){
				loggedInUserpermissionTypeList.add(PermissionType.VIEW);
			}else if(s.equals("EDIT")){
				loggedInUserpermissionTypeList.add(PermissionType.EDIT);
			}else if(s.equals("ADMIN")){
				loggedInUserpermissionTypeList.add(PermissionType.ADMIN);
			}else if(s.equals("BUILD")){
				loggedInUserpermissionTypeList.add(PermissionType.BUILD);
			}else if(s.equals("CLONE")){
				loggedInUserpermissionTypeList.add(PermissionType.CLONE);
			}else if(s.equals("CREATE")){
				loggedInUserpermissionTypeList.add(PermissionType.CREATE);
			}else if(s.equals("DELETE")){
				loggedInUserpermissionTypeList.add(PermissionType.DELETE);
			}
		}
		PermissionType[] loggedInUserpermissionTypeArr = loggedInUserpermissionTypeList.toArray(new PermissionType[loggedInUserpermissionTypeList.size() - 1]);
		permissions = permissions.loggedInUserPermissions(loggedInUserpermissionTypeArr);
	
		DeploymentPermissions deploymentPermission = new DeploymentPermissions(deploymentProjectName)
                .permissions(permissions);
        return deploymentPermission;
	}
	
	public static EnvironmentPermissions getEnvironmentPermission(String fileName, String envKey, String env, String deploymentProjectName){
		
		//logic to get permission for create stack dev
		String countKey = "environment.user.permission." + envKey + "." + env + ".count";
		String count = getPropertyByKey(countKey, fileName);
		Permissions permissions = new Permissions();
		for(int i = 1; i <= Integer.valueOf(count); i++){
			String key = "environment.user.permission." + envKey + "." + env + "." + i;
			String permission = getPropertyByKey(key, fileName);
			String[] permissionArr = permission.split("\\|");
			String user = permissionArr[0];
			List<PermissionType> permissionTypeList = new ArrayList<PermissionType>();
			for(int j = 1; j < permissionArr.length; j++){
				if(permissionArr[j].equals("VIEW")){
					permissionTypeList.add(PermissionType.VIEW);
				}else if(permissionArr[j].equals("EDIT")){
					permissionTypeList.add(PermissionType.EDIT);
				}else if(permissionArr[j].equals("ADMIN")){
					permissionTypeList.add(PermissionType.ADMIN);
				}else if(permissionArr[j].equals("BUILD")){
					permissionTypeList.add(PermissionType.BUILD);
				}else if(permissionArr[j].equals("CLONE")){
					permissionTypeList.add(PermissionType.CLONE);
				}else if(permissionArr[j].equals("CREATE")){
					permissionTypeList.add(PermissionType.CREATE);
				}else if(permissionArr[j].equals("DELETE")){
					permissionTypeList.add(PermissionType.DELETE);
				}
			}
			PermissionType[] permissionTypeArr = permissionTypeList.toArray(new PermissionType[permissionTypeList.size() - 1]);
			permissions = permissions.userPermissions(user, permissionTypeArr);
			
		}
		
		String loggedInUserpermission = getPropertyByKey("environment.login.user.permission." + envKey + "." + env, fileName);
		String[] loggedInUserpermissionArr = loggedInUserpermission.split("\\|");
		List<PermissionType> loggedInUserpermissionTypeList = new ArrayList<PermissionType>();
		for(String s: loggedInUserpermissionArr){
			if(s.equals("VIEW")){
				loggedInUserpermissionTypeList.add(PermissionType.VIEW);
			}else if(s.equals("EDIT")){
				loggedInUserpermissionTypeList.add(PermissionType.EDIT);
			}else if(s.equals("ADMIN")){
				loggedInUserpermissionTypeList.add(PermissionType.ADMIN);
			}else if(s.equals("BUILD")){
				loggedInUserpermissionTypeList.add(PermissionType.BUILD);
			}else if(s.equals("CLONE")){
				loggedInUserpermissionTypeList.add(PermissionType.CLONE);
			}else if(s.equals("CREATE")){
				loggedInUserpermissionTypeList.add(PermissionType.CREATE);
			}else if(s.equals("DELETE")){
				loggedInUserpermissionTypeList.add(PermissionType.DELETE);
			}
		}
		PermissionType[] loggedInUserpermissionTypeArr = loggedInUserpermissionTypeList.toArray(new PermissionType[loggedInUserpermissionTypeList.size() - 1]);
		permissions = permissions.loggedInUserPermissions(loggedInUserpermissionTypeArr);
	
		EnvironmentPermissions environmentPermissions = new EnvironmentPermissions(deploymentProjectName)
				.environmentName(env)
                .permissions(permissions);
        return environmentPermissions;
	}
	
	public static String getPropertyByKey(String key, String fileName){
		String result = "";
		try{
			Properties properties = new Properties();
			InputStream input = Configuration.class.getClassLoader().getResourceAsStream(fileName);
			properties.load(input);
			result = properties.getProperty(key);
		}catch(IOException e){
			e.printStackTrace();
		}
		return result;
	}

}
