package com.usfoods.bamboo.spec.standard.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.atlassian.bamboo.specs.api.BambooSpec;
import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.deployment.Deployment;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.deployment.ReleaseNaming;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.CleanWorkingDirectoryTask;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.usfoods.bamboo.spec.config.Configuration;
import com.usfoods.bamboo.spec.config.PlanPropertyConfig;
import com.usfoods.bamboo.spec.config.ProjectPropertyConfig;
import com.usfoods.bamboo.spec.constant.Constant.TaskClass;
import com.usfoods.bamboo.spec.factory.TaskFactory;
import com.usfoods.bamboo.spec.util.Util;

public class StandardLambdaDeleteStackDeploymentSpec {
	
	public static String propertyFileName = "standard-lambda-project.properties";
	public static String variableConfigFileName = "standard-lambda-deployment-variable.properties";
	public static String envKey = "deletestack";
	public static ProjectPropertyConfig projectProp;
	public static PlanPropertyConfig planProp;
	public static Task pinAWSAgentTask;
	public static Task awsCredentialsVariablesTask;
	public static Task cleanWorkingDirectoryTask;
	public static Task disableTeminatorProtectionTaskDEV;
	public static Task disableTeminatorProtectionTaskSIT;
	public static Task disableTeminatorProtectionTaskQA;
	public static Task disableTeminatorProtectionTaskUAT;
	public static Task disableTeminatorProtectionTaskPERF;
	public static Task disableTeminatorProtectionTaskNonprod;
	public static Task disableTeminatorProtectionTaskProd;
	public static Task awsCloudformationStackDeleteStackTaskDEV;
	public static Task awsCloudformationStackDeleteStackTaskSIT;
	public static Task awsCloudformationStackDeleteStackTaskQA;
	public static Task awsCloudformationStackDeleteStackTaskUAT;
	public static Task awsCloudformationStackDeleteStackTaskPERF;
	public static Task awsCloudformationStackDeleteStackTaskNonprod;
	public static Task awsCloudformationStackDeleteStackTaskProd;
	public static String deploymentProjectName;
	
	public static void init(){
		
		try {
    			projectProp = Configuration.initConfigOfProjectProperty(propertyFileName);
				planProp = Configuration.initConfigOfPlanProperty(propertyFileName);
				deploymentProjectName = projectProp.getRootName() + "-deletestack";
				
				pinAWSAgentTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.PIN_AWS_AGENT_TASK);
				awsCredentialsVariablesTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CREDENTIALS_VARIABLES_TASK);
				
				cleanWorkingDirectoryTask = new CleanWorkingDirectoryTask();
				{//dev environment
					awsCloudformationStackDeleteStackTaskDEV = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK);
					disableTeminatorProtectionTaskDEV = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-dev.properties");
				}
				{//sit environment
					awsCloudformationStackDeleteStackTaskSIT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-sit.properties");
					disableTeminatorProtectionTaskSIT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-sit.properties");
				}
				{//qa environment
					awsCloudformationStackDeleteStackTaskQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-qa.properties");
					disableTeminatorProtectionTaskQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-qa.properties");

				}
				{//uat environment
					awsCloudformationStackDeleteStackTaskUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-uat.properties");
					disableTeminatorProtectionTaskUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-uat.properties");

				}
				{//perf environment
					awsCloudformationStackDeleteStackTaskPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-perf.properties");
					disableTeminatorProtectionTaskPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-perf.properties");

				}
				{//nonprod environment
					awsCloudformationStackDeleteStackTaskNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-nonprod.properties");
					disableTeminatorProtectionTaskNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-nonprod.properties");

				}
				{//prod environment
					awsCloudformationStackDeleteStackTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK, "aws-cloudformation-configuration-task-delete-stack-prod.properties");
					disableTeminatorProtectionTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.DISABLE_TEMINATOR_PROTECTION_TASK, "script-task-disable-termination-protection-prod.properties");

				}

		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
    
    public Deployment rootObject() {
    	
    	

    	
    	//get Env
    	String[] envArr = projectProp.getProjectEnv().split("\\|");
    	List<String> envList = Arrays.asList(envArr);
    	List<Environment> environmentList = new ArrayList<Environment>();
    	//if dev exits
    	//create DEV environment object
    	if(envList.contains("DEV")){
    		Environment env = new Environment("dev")
                  .tasks(cleanWorkingDirectoryTask,
            		pinAWSAgentTask,
            		awsCredentialsVariablesTask,
            		disableTeminatorProtectionTaskDEV,
            		awsCloudformationStackDeleteStackTaskDEV);
    		environmentList.add(env);
    	}
    	
    	//if qa exists
    	//create qa environment object
    	if(envList.contains("QA")){
    		Environment env = new Environment("qa")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskQA,
              		awsCloudformationStackDeleteStackTaskQA);
    		environmentList.add(env);
    	}
    	
    	//if sit exists
    	//create sit environment object
    	if(envList.contains("SIT")){
    		Environment env = new Environment("sit")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskSIT,
              		awsCloudformationStackDeleteStackTaskSIT);
    		environmentList.add(env);
    	}
    	
    	//if uat exists
    	//create uat environment object
    	if(envList.contains("UAT")){
    		Environment env = new Environment("uat")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskUAT,
              		awsCloudformationStackDeleteStackTaskUAT);
    		environmentList.add(env);
    	}
    	
    	//if perf exists
    	//create perf environment object
    	if(envList.contains("PERF")){
    		Environment env = new Environment("perf")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskPERF,
              		awsCloudformationStackDeleteStackTaskPERF);
    		environmentList.add(env);
    	}
    	
    	//if nonprod exists
    	//create nonprod environment object
    	if(envList.contains("NONPROD")){
    		Environment env = new Environment("nonprod")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskNonprod,
              		awsCloudformationStackDeleteStackTaskNonprod);
    		environmentList.add(env);
    	}
    	
    	//if prod exists
    	//create prod environment object
    	if(envList.contains("PROD")){
    		Environment env = new Environment("prod")
                    .tasks(cleanWorkingDirectoryTask,
              		pinAWSAgentTask,
              		awsCredentialsVariablesTask,
              		disableTeminatorProtectionTaskProd,
              		awsCloudformationStackDeleteStackTaskProd);
    		environmentList.add(env);
    	}
    	//create Environment List
    	Environment[] environmentArr = environmentList.toArray(new Environment[environmentList.size()]);
    	//.environments(EnvironmentList)
    	final Deployment rootObject = new Deployment(new PlanIdentifier(projectProp.getBambooKey(), planProp.getBambooKey()),
        		deploymentProjectName)
              .releaseNaming(new ReleaseNaming("release-1")
              .autoIncrement(true))
              .environments(environmentArr);
    
        return rootObject;
    
    }
    
    public DeploymentPermissions deploymentPermission() {
    	
    	final DeploymentPermissions deploymentPermission = Util.getDeploymentPermission(variableConfigFileName, envKey, deploymentProjectName);
    	
        return deploymentPermission;
    }
    
    public EnvironmentPermissions environmentPermissionDev() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "dev", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionSit() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "sit", deploymentProjectName);
    	return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionQa() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "qa", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionUat() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "uat", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionPerf() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "perf", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionNonProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "nonprod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "prod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public static void main(String... argv) {
        //By default credentials are read from the '.credentials' file.
    	init();
    	BambooServer bambooServer = new BambooServer(projectProp.getBambooHostname());
        final StandardLambdaDeleteStackDeploymentSpec planSpec = new StandardLambdaDeleteStackDeploymentSpec();
        
        final Deployment rootObject = planSpec.rootObject();
        bambooServer.publish(rootObject);
        
        final DeploymentPermissions deploymentPermission = planSpec.deploymentPermission();
        bambooServer.publish(deploymentPermission);
        
        final EnvironmentPermissions environmentPermission1 = planSpec.environmentPermissionDev();
        bambooServer.publish(environmentPermission1);
        
        final EnvironmentPermissions environmentPermission2 = planSpec.environmentPermissionSit();
        bambooServer.publish(environmentPermission2);
    }
}