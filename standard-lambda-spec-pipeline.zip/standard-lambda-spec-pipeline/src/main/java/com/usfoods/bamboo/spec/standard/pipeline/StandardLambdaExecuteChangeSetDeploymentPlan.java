package com.usfoods.bamboo.spec.standard.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.atlassian.bamboo.specs.api.BambooSpec;
import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.deployment.Deployment;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.deployment.ReleaseNaming;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.ArtifactDownloaderTask;
import com.atlassian.bamboo.specs.builders.task.CleanWorkingDirectoryTask;
import com.atlassian.bamboo.specs.builders.task.DownloadItem;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.usfoods.bamboo.spec.config.Configuration;
import com.usfoods.bamboo.spec.config.PlanPropertyConfig;
import com.usfoods.bamboo.spec.config.ProjectPropertyConfig;
import com.usfoods.bamboo.spec.config.VariableConfig;
import com.usfoods.bamboo.spec.constant.Constant.TaskClass;
import com.usfoods.bamboo.spec.factory.TaskFactory;
import com.usfoods.bamboo.spec.util.Util;

public class StandardLambdaExecuteChangeSetDeploymentPlan {
	
	public static String propertyFileName = "standard-lambda-project.properties";
	public static String variableConfigFileName = "standard-lambda-deployment-variable.properties";
	public static String envKey = "executechangeset";
	public static ProjectPropertyConfig projectProp;
	public static PlanPropertyConfig planProp;
	public static Task pinAWSAgentTask;
	public static Task artifactDownloadTaskParaDev;
	public static Task artifactDownloadTaskParaSit;
	public static Task artifactDownloadTaskParaQA;
	public static Task artifactDownloadTaskParaUAT;
	public static Task artifactDownloadTaskParaPERF;
	public static Task artifactDownloadTaskParaNonprod;
	public static Task artifactDownloadTaskParaProd;
	public static Task cleanWorkingDirectoryTask;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskDEV;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskSIT;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskQA;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskUAT;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskPERF;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskNonprod;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskProd;
	public static Task awsCloudformationStackExecuteChangeStack;
	public static Task awsCloudformationStackExecuteChangeStackDEV;
	public static Task awsCloudformationStackExecuteChangeStackSIT;
	public static Task awsCloudformationStackExecuteChangeStackQA;
	public static Task awsCloudformationStackExecuteChangeStackUAT;
	public static Task awsCloudformationStackExecuteChangeStackPERF;
	public static Task awsCloudformationStackExecuteChangeStackNonprod;
	public static Task awsCloudformationStackExecuteChangeStackProd;
	public static String deploymentProjectName;
	public static VariableConfig variableConfig;
	
	public static void init(){
		
		try {
				projectProp = Configuration.initConfigOfProjectProperty(propertyFileName);
				planProp = Configuration.initConfigOfPlanProperty(propertyFileName);
				variableConfig = Configuration.initVariableConfig(variableConfigFileName);
				deploymentProjectName = projectProp.getRootName() + "-executechangeset";
				{//dev environment
					pinAWSAgentTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.PIN_AWS_AGENT_TASK);
					artifactDownloadTaskParaDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-dev.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskDEV = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-dev.properties");
					awsCloudformationStackExecuteChangeStackDEV = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-dev.properties");
					cleanWorkingDirectoryTask = new CleanWorkingDirectoryTask();
				
				}
				{//sit environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskSIT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-sit.properties");
					awsCloudformationStackExecuteChangeStackSIT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-sit.properties");
					artifactDownloadTaskParaSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-sit.properties");
				}
				{//qa environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-qa.properties");
					awsCloudformationStackExecuteChangeStackQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-qa.properties");
					artifactDownloadTaskParaQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-qa.properties");
				}
				{//uat environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-uat.properties");
					awsCloudformationStackExecuteChangeStackUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-uat.properties");
					artifactDownloadTaskParaUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-uat.properties");
				}
				{//perf environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-perf.properties");
					awsCloudformationStackExecuteChangeStackPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-perf.properties");
					artifactDownloadTaskParaPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-perf.properties");
				}
				{//nonprod environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-nonprod.properties");
					awsCloudformationStackExecuteChangeStackNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-nonprod.properties");
					artifactDownloadTaskParaNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-nonprod.properties");
				}
				{//prod environment
					awsLambdaFunctionUpdateEnvironmentVariablesTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-prod.properties");
					awsCloudformationStackExecuteChangeStackProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK, "aws-cloudformation-configuration-task-execute-changeset-prod.properties");
					artifactDownloadTaskParaProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-prod.properties");
				}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
    
    public Deployment rootObject() {
    	
    	//get Env
    	String[] envArr = projectProp.getProjectEnv().split("\\|");
    	List<String> envList = Arrays.asList(envArr);
    	List<Environment> environmentList = new ArrayList<Environment>();
    	//if dev exits
    	//create DEV environment object
    	if(envList.contains("DEV")){
    		Environment env = new Environment("dev")
            .tasks(cleanWorkingDirectoryTask,
            		artifactDownloadTaskParaDev,
            		pinAWSAgentTask,
            		awsCloudformationStackExecuteChangeStackDEV,
                new ArtifactDownloaderTask()
                    .description("Environment Variables download")
                    .artifacts(new DownloadItem()
                            .artifact("stack_env_dev")),
                    pinAWSAgentTask,
                    awsLambdaFunctionUpdateEnvironmentVariablesTaskDEV)
            .variables(new Variable(variableConfig.getKey1(),
            		variableConfig.getValue1() + "_dev"));
    		environmentList.add(env);
    	}
    	
    	//if qa exists
    	//create qa environment object
    	if(envList.contains("QA")){
    		Environment env = new Environment("qa")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaQA,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackQA,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_qa")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskQA)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_qa"));
    		environmentList.add(env);
    	}
    	
    	//if sit exists
    	//create sit environment object
    	if(envList.contains("SIT")){
    		Environment env = new Environment("sit")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaSit,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackSIT,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_sit")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskSIT)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_sit"));
    		environmentList.add(env);
    	}
    	
    	//if uat exists
    	//create uat environment object
    	if(envList.contains("UAT")){
    		Environment env = new Environment("uat")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaUAT,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackUAT,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_uat")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskUAT)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_uat"));
    		environmentList.add(env);
    	}
    	
    	
    	//if perf exists
    	//create perf environment object
    	if(envList.contains("PERF")){
    		Environment env = new Environment("perf")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaPERF,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackPERF,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_perf")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskPERF)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_perf"));
    		environmentList.add(env);
    	}
    	
    	//if nonprod exists
    	//create nonprod environment object
    	if(envList.contains("NONPROD")){
    		Environment env = new Environment("nonprod")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaNonprod,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackNonprod,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_nonprod")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskNonprod)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_nonprod"));
    		environmentList.add(env);
    	}
    	
    	//if prod exists
    	//create prod environment object
    	if(envList.contains("PROD")){
    		Environment env = new Environment("prod")
    	            .tasks(cleanWorkingDirectoryTask,
    	            		artifactDownloadTaskParaProd,
    	            		pinAWSAgentTask,
    	            		awsCloudformationStackExecuteChangeStackProd,
    	                new ArtifactDownloaderTask()
    	                    .description("Environment Variables download")
    	                    .artifacts(new DownloadItem()
    	                            .artifact("stack_env_prod")),
    	                    pinAWSAgentTask,
    	                    awsLambdaFunctionUpdateEnvironmentVariablesTaskProd)
    	            .variables(new Variable(variableConfig.getKey1(),
    	            		variableConfig.getValue1() + "_prod"));
    		environmentList.add(env);
    	}
    	//create Environment List
    	Environment[] environmentArr = environmentList.toArray(new Environment[environmentList.size()]);
    	//.environments(EnvironmentList)
    	final Deployment rootObject = new Deployment(new PlanIdentifier(projectProp.getBambooKey(), planProp.getBambooKey()),
        		deploymentProjectName)
              .releaseNaming(new ReleaseNaming("release-1")
              .autoIncrement(true))
              .environments(environmentArr);
    
        return rootObject;
    }
    
    public DeploymentPermissions deploymentPermission() {
    	
    	final DeploymentPermissions deploymentPermission = Util.getDeploymentPermission(variableConfigFileName, envKey, deploymentProjectName);
        return deploymentPermission;
    }
    
    public EnvironmentPermissions environmentPermissionDev() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "dev", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionSit() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "sit", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionQa() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "qa", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionUat() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "uat", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionPerf() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "perf", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionNonProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "nonprod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "prod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public static void main(String... argv) {
        //By default credentials are read from the '.credentials' file.
    	init();
    	BambooServer bambooServer = new BambooServer(projectProp.getBambooHostname());
        final StandardLambdaExecuteChangeSetDeploymentPlan planSpec = new StandardLambdaExecuteChangeSetDeploymentPlan();
        
        final Deployment rootObject = planSpec.rootObject();
        bambooServer.publish(rootObject);
        
        final DeploymentPermissions deploymentPermission = planSpec.deploymentPermission();
        bambooServer.publish(deploymentPermission);
        
        final EnvironmentPermissions environmentPermission1 = planSpec.environmentPermissionDev();
        bambooServer.publish(environmentPermission1);
        
        final EnvironmentPermissions environmentPermission2 = planSpec.environmentPermissionSit();
        bambooServer.publish(environmentPermission2);
    }
}
