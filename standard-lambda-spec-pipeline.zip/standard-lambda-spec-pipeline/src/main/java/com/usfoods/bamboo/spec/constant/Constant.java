package com.usfoods.bamboo.spec.constant;

public final class Constant {
	public static final class TaskClass{
		public static final String PIN_AWS_AGENT_TASK = "com.usfoods.bamboo.spec.task.add.requirement.warehouse.USFPinAWSAgentTask";
		public static final String SOURCE_CHECKOUT_TASK = "com.usfoods.bamboo.spec.task.sourcecode.checkout.warehouse.USFSourcecodeCheckoutTask";
		public static final String UPLOAD_S3_ENV_VAR_TASK = "com.usfoods.bamboo.spec.task.amazon.s3.object.warehouse.USFUploadS3EnvVarTask";
		public static final String UPLOAD_S3_PARA_TASK = "com.usfoods.bamboo.spec.task.amazon.s3.object.warehouse.USFUploadS3ParameterTask";
		public static final String UPLOAD_S3_ROOT_TEMPLATE_TASK = "com.usfoods.bamboo.spec.task.amazon.s3.object.warehouse.USFUploadS3RootTemplate";

		public static final String AWS_CLOUDFORMATION_STACK_CREATE_CHANGESET_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackCreateChangeStackTask";
		public static final String AWS_CLOUDFORMATION_STACK_DELETE_CHANGESET_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackDeleteChangeStack";
		public static final String AWS_CREDENTIALS_VARIABLES_TASK = "com.usfoods.bamboo.spec.task.aws.credentials.variables.warehouse.AWSCredentialsVariablesTask";
		public static final String AWS_CLOUDFORMATION_STACK_VALIDATE_ROOT_TEMPLATE_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackValidateRootTemplateTask";
		public static final String AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackCreateStackTask";
		public static final String AWS_CLOUDFORMATION_STACK_DELETE_STACK_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackDeleteStackTask";
		public static final String AWS_CLOUDFORMATION_STACK_EXECUTE_CHANGESET_TASK = "com.usfoods.bamboo.spec.task.aws.cloudformation.stack.warehouse.AWSCloudformationStackExecuteChangeStack";

		public static final String DESCRIBE_CHANGESET_TASK = "com.usfoods.bamboo.spec.task.script.warehouse.DescribeChangesetTask";
		public static final String ARTIFACT_DOWNLOAD_TASK = "com.usfoods.bamboo.spec.task.artifact.download.warehouse.ArtifactDownloadTask";

		public static final String AWS_LAMBDA_FUNCTION_TASK = "com.usfoods.bamboo.spec.aws.lambda.function.warehouse.AWSLambdaFunctionTask";
		public static final String AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK = "com.usfoods.bamboo.spec.aws.lambda.function.warehouse.AWSLambdaFunctionUpdateEnvironmentVariablesTask";
		public static final String ENABLE_TEMINATOR_PROTECTION_TASK = "com.usfoods.bamboo.spec.task.script.warehouse.EnableTeminatorProtectionTask";
		public static final String DISABLE_TEMINATOR_PROTECTION_TASK = "com.usfoods.bamboo.spec.task.script.warehouse.DisableTeminatorProtectionTask";
		public static final String SCRIPT_TASK = "com.usfoods.bamboo.spec.task.script.warehouse.ScriptTask";
		
	}

}
