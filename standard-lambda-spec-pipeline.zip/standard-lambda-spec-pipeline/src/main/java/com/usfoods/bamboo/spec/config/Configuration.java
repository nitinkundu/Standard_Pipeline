package com.usfoods.bamboo.spec.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configuration {
	
	private static String FILENAME = "project.properties";

	public static PlanPropertyConfig initConfigOfPlanProperty(){
		
		PlanPropertyConfig planProp = new PlanPropertyConfig();
		planProp.setBambooKey(Configuration.getPropertyByKey("plan.bamboo.key"));
		planProp.setBambooDescription(Configuration.getPropertyByKey("plan.bamboo.description"));
		planProp.setBambooName(Configuration.getPropertyByKey("plan.bamboo.name"));
		return planProp;
	}
	
	public static PlanPropertyConfig initConfigOfPlanProperty(String fileName){
		
		PlanPropertyConfig planProp = new PlanPropertyConfig();
		planProp.setBambooKey(Configuration.getPropertyByKey("plan.bamboo.key", fileName));
		planProp.setBambooDescription(Configuration.getPropertyByKey("plan.bamboo.description", fileName));
		planProp.setBambooName(Configuration.getPropertyByKey("plan.bamboo.name", fileName));
		return planProp;
	}
	
	public static ProjectPropertyConfig initConfigOfProjectProperty(){
		ProjectPropertyConfig projectProp = new ProjectPropertyConfig();
		projectProp.setBambooKey(Configuration.getPropertyByKey("project.bamboo.key"));
		projectProp.setBambooDescription(Configuration.getPropertyByKey("project.bamboo.description"));
		projectProp.setBambooName(Configuration.getPropertyByKey("project.bamboo.name"));
		projectProp.setBambooHostname(Configuration.getPropertyByKey("project.bamboo.hostname"));
		projectProp.setRootName(Configuration.getPropertyByKey("project.root.name"));
		return projectProp;
	}
	
	public static ProjectPropertyConfig initConfigOfProjectProperty(String fileName){
		ProjectPropertyConfig projectProp = new ProjectPropertyConfig();
		projectProp.setBambooKey(Configuration.getPropertyByKey("project.bamboo.key", fileName));
		projectProp.setBambooDescription(Configuration.getPropertyByKey("project.bamboo.description", fileName));
		projectProp.setBambooName(Configuration.getPropertyByKey("project.bamboo.name", fileName));
		projectProp.setBambooHostname(Configuration.getPropertyByKey("project.bamboo.hostname", fileName));
		projectProp.setRootName(Configuration.getPropertyByKey("project.root.name", fileName));
		projectProp.setProjectEnv(Configuration.getPropertyByKey("project.deployment.env", fileName));
		return projectProp;
	}
	
	public static RepoPropertyConfig initRepoPropertyConfig(){
		RepoPropertyConfig repoPropertyConfig = new RepoPropertyConfig();
		repoPropertyConfig.setProjectKey(Configuration.getPropertyByKey("plan.repo.projectKey"));
		repoPropertyConfig.setRepoName(Configuration.getPropertyByKey("plan.repo.name"));
		repoPropertyConfig.setRepoServerId(Configuration.getPropertyByKey("plan.repo.server.id"));
		repoPropertyConfig.setRepoServerName(Configuration.getPropertyByKey("plan.repo.server.name"));
		repoPropertyConfig.setRepositorySlug(Configuration.getPropertyByKey("plan.repo.repositorySlug"));
		repoPropertyConfig.setSshCloneUrl(Configuration.getPropertyByKey("plan.repo.sshCloneUrl"));
		repoPropertyConfig.setSshPrivateKey(Configuration.getPropertyByKey("plan.repo.sshPrivateKey"));
		repoPropertyConfig.setSshPublicKey(Configuration.getPropertyByKey("plan.repo.sshPublicKey"));
		return repoPropertyConfig;	
	}
	
	public static RepoPropertyConfig initRepoPropertyConfig(String fileName){
		RepoPropertyConfig repoPropertyConfig = new RepoPropertyConfig();
		repoPropertyConfig.setProjectKey(Configuration.getPropertyByKey("plan.repo.projectKey", fileName));
		repoPropertyConfig.setRepoName(Configuration.getPropertyByKey("plan.repo.name", fileName));
		repoPropertyConfig.setRepoServerId(Configuration.getPropertyByKey("plan.repo.server.id", fileName));
		repoPropertyConfig.setRepoServerName(Configuration.getPropertyByKey("plan.repo.server.name", fileName));
		repoPropertyConfig.setRepositorySlug(Configuration.getPropertyByKey("plan.repo.repositorySlug", fileName));
		repoPropertyConfig.setSshCloneUrl(Configuration.getPropertyByKey("plan.repo.sshCloneUrl", fileName));
		repoPropertyConfig.setSshPrivateKey(Configuration.getPropertyByKey("plan.repo.sshPrivateKey", fileName));
		repoPropertyConfig.setSshPublicKey(Configuration.getPropertyByKey("plan.repo.sshPublicKey", fileName));
		return repoPropertyConfig;	
	}
	
	public static UploadEnvVariableJobPropertyConfig initUploadEnvVariableJobPropertyConfig(){
		
		UploadEnvVariableJobPropertyConfig config = new UploadEnvVariableJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name"));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern"));
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-env-variable.key"));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-env-variable.name"));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name"));
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable")));
		return config;		
	}
	
	public static UploadEnvVariableJobPropertyConfig initUploadEnvVariableJobPropertyConfig(String fileName){
		
		UploadEnvVariableJobPropertyConfig config = new UploadEnvVariableJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name", fileName));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern", fileName));
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable", fileName)));
	
		config.setArtifactNameDev(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.dev", fileName));
		config.setCopyPatternDev(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.dev", fileName));
		config.setSharableDev(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.dev", fileName)));
		
		config.setArtifactNameSit(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.sit", fileName));
		config.setCopyPatternSit(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.sit", fileName));
		config.setSharableSit(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.sit", fileName)));
		
		config.setArtifactNameUat(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.uat", fileName));
		config.setCopyPatternUat(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.uat", fileName));
		config.setSharableUat(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.uat", fileName)));
		
		config.setArtifactNameQa(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.qa", fileName));
		config.setCopyPatternQa(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.qa", fileName));
		config.setSharableQa(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.qa", fileName)));
		
		config.setArtifactNameNonprod(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.nonprod", fileName));
		config.setCopyPatternNonprod(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.nonprod", fileName));
		config.setSharableNonprod(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.nonprod", fileName)));
		
		config.setArtifactNamePerf(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.perf", fileName));
		config.setCopyPatternPerf(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.perf", fileName));
		config.setSharablePerf(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.perf", fileName)));
		
		config.setArtifactNameProd(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.name.prod", fileName));
		config.setCopyPatternProd(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.copyPattern.prod", fileName));
		config.setSharableProd(new Boolean(Configuration.getPropertyByKey("plan.job.upload-env-variable.artifact.sharable.prod", fileName)));
		
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-env-variable.key", fileName));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-env-variable.name", fileName));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name", fileName));

		return config;		
	}
	
	public static UploadParameterFileJobPropertyConfig initUploadParameterFileJobPropertyConfig(){
		
		UploadParameterFileJobPropertyConfig config = new UploadParameterFileJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name"));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern"));
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-parameter-file.key"));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-parameter-file.name"));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name"));
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable")));
		
		//add dev,sit,uat, perf and prod
		config.setArtifactNameDev(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.dev"));
		config.setCopyPatternDev(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.dev"));
		config.setSharableDev(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.dev")));
		
		config.setArtifactNameSit(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.sit"));
		config.setCopyPatternSit(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.sit"));
		config.setSharableSit(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.sit")));
		
		config.setArtifactNameUat(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.uat"));
		config.setCopyPatternUat(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.uat"));
		config.setSharableUat(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.uat")));

		config.setArtifactNamePerf(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.perf"));
		config.setCopyPatternPerf(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.perf"));
		config.setSharablePerf(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.perf")));
		
		config.setArtifactNameProd(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.prod"));
		config.setCopyPatternProd(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.prod"));
		config.setSharableProd(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.prod")));
		
		return config;		
	}
	
	public static UploadParameterFileJobPropertyConfig initUploadParameterFileJobPropertyConfig(String fileName){
		
		UploadParameterFileJobPropertyConfig config = new UploadParameterFileJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name", fileName));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern", fileName));
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-parameter-file.key", fileName));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-parameter-file.name", fileName));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name", fileName));
		//add dev,sit,uat and prod
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable", fileName)));
		
		config.setArtifactNameDev(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.dev", fileName));
		config.setCopyPatternDev(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.dev", fileName));
		config.setSharableDev(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.dev", fileName)));
		
		config.setArtifactNameSit(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.sit", fileName));
		config.setCopyPatternSit(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.sit", fileName));
		config.setSharableSit(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.sit", fileName)));
		
		config.setArtifactNameUat(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.uat", fileName));
		config.setCopyPatternUat(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.uat", fileName));
		config.setSharableUat(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.uat", fileName)));
		
		config.setArtifactNameQa(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.qa", fileName));
		config.setCopyPatternQa(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.qa", fileName));
		config.setSharableQa(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.qa", fileName)));
		
		config.setArtifactNameNonprod(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.nonprod", fileName));
		config.setCopyPatternNonprod(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.nonprod", fileName));
		config.setSharableNonprod(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.nonprod", fileName)));
		
		config.setArtifactNamePerf(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.perf", fileName));
		config.setCopyPatternPerf(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.perf", fileName));
		config.setSharablePerf(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.perf", fileName)));
		
		config.setArtifactNameProd(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.name.prod", fileName));
		config.setCopyPatternProd(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.copyPattern.prod", fileName));
		config.setSharableProd(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable.prod", fileName)));
		return config;		
	}
	
	public static VariableConfig initVariableConfig(){
		VariableConfig variableConfig = new VariableConfig();
		variableConfig.setKey1(Configuration.getPropertyByKey("plan.variable.1.key"));
		variableConfig.setValue1(Configuration.getPropertyByKey("plan.variable.1.value"));
		variableConfig.setKey2(Configuration.getPropertyByKey("plan.variable.2.key"));
		variableConfig.setValue2(Configuration.getPropertyByKey("plan.variable.2.value"));
		variableConfig.setKey3(Configuration.getPropertyByKey("plan.variable.3.key"));
		variableConfig.setValue3(Configuration.getPropertyByKey("plan.variable.3.value"));
		variableConfig.setKey4(Configuration.getPropertyByKey("plan.variable.4.key"));
		variableConfig.setValue4(Configuration.getPropertyByKey("plan.variable.4.value"));
		variableConfig.setKey5(Configuration.getPropertyByKey("plan.variable.5.key"));
		variableConfig.setValue5(Configuration.getPropertyByKey("plan.variable.5.value"));
		return variableConfig;	
	}
	
	public static VariableConfig initVariableConfig(String fileName){
		VariableConfig variableConfig = new VariableConfig();
		variableConfig.setKey1(Configuration.getPropertyByKey("plan.variable.1.key", fileName));
		variableConfig.setValue1(Configuration.getPropertyByKey("plan.variable.1.value", fileName));
		variableConfig.setKey2(Configuration.getPropertyByKey("plan.variable.2.key", fileName));
		variableConfig.setValue2(Configuration.getPropertyByKey("plan.variable.2.value", fileName));
		variableConfig.setKey3(Configuration.getPropertyByKey("plan.variable.3.key", fileName));
		variableConfig.setValue3(Configuration.getPropertyByKey("plan.variable.3.value", fileName));
		variableConfig.setKey4(Configuration.getPropertyByKey("plan.variable.4.key", fileName));
		variableConfig.setValue4(Configuration.getPropertyByKey("plan.variable.4.value", fileName));
		variableConfig.setKey5(Configuration.getPropertyByKey("plan.variable.5.key", fileName));
		variableConfig.setValue5(Configuration.getPropertyByKey("plan.variable.5.value", fileName));
		return variableConfig;	
	}
	
	public static UploadTemplateJobPropertyConfig initUploadTemplateJobPropertyConfig(){
		UploadTemplateJobPropertyConfig config = new UploadTemplateJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-template.artifact.name"));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-template.artifact.copyPattern"));
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-template.key"));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-template.name"));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name"));
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable")));
		return config;	
	}
	
	public static UploadTemplateJobPropertyConfig initUploadTemplateJobPropertyConfig(String fileName){
		UploadTemplateJobPropertyConfig config = new UploadTemplateJobPropertyConfig();
		config.setArtifactName(Configuration.getPropertyByKey("plan.job.upload-template.artifact.name", fileName));
		config.setCopyPattern(Configuration.getPropertyByKey("plan.job.upload-template.artifact.copyPattern", fileName));
		config.setJobKey(Configuration.getPropertyByKey("plan.job.upload-template.key", fileName));
		config.setJobName(Configuration.getPropertyByKey("plan.job.upload-template.name", fileName));
		config.setJobType(Configuration.getPropertyByKey("plan.repo.name", fileName));
		config.setSharable(new Boolean(Configuration.getPropertyByKey("plan.job.upload-parameter-file.artifact.sharable", fileName)));
		return config;	
	}
	
	public static String getPropertyByKey(String key){
		String result = "";
		Properties properties = new Properties();
		InputStream input = null;
		try{
			properties = new Properties();
			input = Configuration.class.getClassLoader().getResourceAsStream(FILENAME);
			properties.load(input);
			result = properties.getProperty(key);
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public static String getPropertyByKey(String key, String fileName){
		String result = "";
		Properties properties = new Properties();
		InputStream input = null;
		try{
			properties = new Properties();
			input = Configuration.class.getClassLoader().getResourceAsStream(fileName);
			properties.load(input);
			result = properties.getProperty(key);
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
}
