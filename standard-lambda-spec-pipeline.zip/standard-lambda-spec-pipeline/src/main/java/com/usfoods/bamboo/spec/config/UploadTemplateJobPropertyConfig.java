package com.usfoods.bamboo.spec.config;

public class UploadTemplateJobPropertyConfig {

	private String jobType;
	
	private String jobName;
	
	private String jobKey;
	
	private String artifactName;
	
	private String copyPattern;
	
	private Boolean sharable;

    public UploadTemplateJobPropertyConfig uploadTemplateJobPropertyConfig(){
    	UploadTemplateJobPropertyConfig uploadTemplateJobPropertyConfig = new UploadTemplateJobPropertyConfig();
		return uploadTemplateJobPropertyConfig;
    }

	public String getJobType() {
		return jobType;
	}

	public String getJobName() {
		return jobName;
	}

	public String getJobKey() {
		return jobKey;
	}

	public String getArtifactName() {
		return artifactName;
	}

	public String getCopyPattern() {
		return copyPattern;
	}

	public Boolean getSharable() {
		return sharable;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public void setArtifactName(String artifactName) {
		this.artifactName = artifactName;
	}

	public void setCopyPattern(String copyPattern) {
		this.copyPattern = copyPattern;
	}

	public void setSharable(Boolean sharable) {
		this.sharable = sharable;
	}
    
    
	
	
}
