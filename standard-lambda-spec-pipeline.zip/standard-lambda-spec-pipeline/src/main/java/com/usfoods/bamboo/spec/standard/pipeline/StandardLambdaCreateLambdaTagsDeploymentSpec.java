package com.usfoods.bamboo.spec.standard.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.deployment.Deployment;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.deployment.ReleaseNaming;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.CleanWorkingDirectoryTask;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.usfoods.bamboo.spec.config.Configuration;
import com.usfoods.bamboo.spec.config.PlanPropertyConfig;
import com.usfoods.bamboo.spec.config.ProjectPropertyConfig;
import com.usfoods.bamboo.spec.config.VariableConfig;
import com.usfoods.bamboo.spec.constant.Constant.TaskClass;
import com.usfoods.bamboo.spec.factory.TaskFactory;
import com.usfoods.bamboo.spec.util.Util;

public class StandardLambdaCreateLambdaTagsDeploymentSpec {
	
	public static String propertyFileName = "standard-lambda-project.properties";
	public static String variableConfigFileName = "standard-lambda-deployment-variable.properties";
	public static String envKey = "createlambdatags";
	public static ProjectPropertyConfig projectProp;
	public static PlanPropertyConfig planProp;
	public static Task cleanWorkingDirectoryTask;
	public static Task awsLambdaFunctionTaskDEV;
	public static Task awsLambdaFunctionTaskSIT;
	public static Task awsLambdaFunctionTaskUAT;
	public static Task awsLambdaFunctionTaskPERF;
	public static Task awsLambdaFunctionTaskQA;
	public static Task awsLambdaFunctionTaskPROD;
	public static String deploymentProjectName;
	public static VariableConfig variableConfig;
	
	public static void init(){
		
		try {
		    	projectProp = Configuration.initConfigOfProjectProperty(propertyFileName);
				planProp = Configuration.initConfigOfPlanProperty(propertyFileName);
				variableConfig = Configuration.initVariableConfig(variableConfigFileName);
				deploymentProjectName = projectProp.getRootName() + "-createlambdatags";
				{//dev environment
					awsLambdaFunctionTaskDEV = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK);
					cleanWorkingDirectoryTask = new CleanWorkingDirectoryTask();
				}
				{//sit environment
					awsLambdaFunctionTaskSIT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK, "aws-lambda-function-configuration-sit.properties");
				}
				{//uat environment
					awsLambdaFunctionTaskUAT = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK, "aws-lambda-function-configuration-uat.properties");
				}
				{//qa environment
					awsLambdaFunctionTaskQA = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK, "aws-lambda-function-configuration-qa.properties");
				}
				{//perf environment
					awsLambdaFunctionTaskPERF = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK, "aws-lambda-function-configuration-perf.properties");
				}
				{//prod environment
					awsLambdaFunctionTaskPROD = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_TASK, "aws-lambda-function-configuration-prod.properties");
				}

		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	
	}
    
    public Deployment rootObject() {
    	
    	//get Env
    	String[] envArr = projectProp.getProjectEnv().split("\\|");
    	List<String> envList = Arrays.asList(envArr);
    	List<Environment> environmentList = new ArrayList<Environment>();
    	//if dev exits
    	//create DEV environment object
    	if(envList.contains("DEV")){
    		Environment env = new Environment("dev")
                  .tasks(cleanWorkingDirectoryTask,
                		  awsLambdaFunctionTaskDEV)
                  .variables(new Variable(variableConfig.getKey1(),
            		variableConfig.getValue1() + "_dev"));
    		environmentList.add(env);
    	}
    	
    	//if qa exists
    	//create qa environment object
    	if(envList.contains("QA")){
    		Environment env = new Environment("qa")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskQA)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_qa"));
    		environmentList.add(env);
    	}
    	
    	//if sit exists
    	//create sit environment object
    	if(envList.contains("SIT")){
    		Environment env = new Environment("sit")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskSIT)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_sit"));
    		environmentList.add(env);
    	}
    	
    	//if uat exists
    	//create uat environment object
    	if(envList.contains("UAT")){
    		Environment env = new Environment("uat")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskUAT)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_UAT"));
    		environmentList.add(env);
    	}
    	
    	//if perf exists
    	//create perf environment object
    	if(envList.contains("PERF")){
    		Environment env = new Environment("perf")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskPERF)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_perf"));
    		environmentList.add(env);
    	}
    	
    	//if nonprod exists
    	//create nonprod environment object
    	if(envList.contains("NONPROD")){
    		Environment env = new Environment("nonprod")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskDEV)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_nonprod"));
    		environmentList.add(env);
    	}
    	
    	//if prod exists
    	//create prod environment object
    	if(envList.contains("PROD")){
    		Environment env = new Environment("prod")
                    .tasks(cleanWorkingDirectoryTask,
                    		awsLambdaFunctionTaskPROD)
                    .variables(new Variable(variableConfig.getKey1(),
              		variableConfig.getValue1() + "_prod"));
    		environmentList.add(env);
    	}
    	//create Environment List
    	Environment[] environmentArr = environmentList.toArray(new Environment[environmentList.size()]);
    	//.environments(EnvironmentList)
    	final Deployment rootObject = new Deployment(new PlanIdentifier(projectProp.getBambooKey(), planProp.getBambooKey()),
        		deploymentProjectName)
              .releaseNaming(new ReleaseNaming("release-1")
              .autoIncrement(true))
              .environments(environmentArr);
    
        return rootObject;
    	
    }
    
    public DeploymentPermissions deploymentPermission() {
    	
    	final DeploymentPermissions deploymentPermission = Util.getDeploymentPermission(variableConfigFileName, envKey, deploymentProjectName);
        return deploymentPermission;
    }
    
    public EnvironmentPermissions environmentPermissionDev() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "dev", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionSit() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "sit", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionQa() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "qa", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionUat() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "uat", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionPerf() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "perf", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionNonProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "nonprod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "prod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public static void main(String... argv) {
        //By default credentials are read from the '.credentials' file.
    	init();
    	BambooServer bambooServer = new BambooServer(projectProp.getBambooHostname());
        final StandardLambdaCreateLambdaTagsDeploymentSpec planSpec = new StandardLambdaCreateLambdaTagsDeploymentSpec();
        
        final Deployment rootObject = planSpec.rootObject();
        bambooServer.publish(rootObject);
        
        final DeploymentPermissions deploymentPermission = planSpec.deploymentPermission();
        bambooServer.publish(deploymentPermission);
        
        final EnvironmentPermissions environmentPermission1 = planSpec.environmentPermissionDev();
        bambooServer.publish(environmentPermission1);
        
        final EnvironmentPermissions environmentPermission2 = planSpec.environmentPermissionSit();
        bambooServer.publish(environmentPermission2);
    }
}