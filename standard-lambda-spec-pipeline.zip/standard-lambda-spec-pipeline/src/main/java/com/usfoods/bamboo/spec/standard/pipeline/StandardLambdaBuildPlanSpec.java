package com.usfoods.bamboo.spec.standard.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.atlassian.bamboo.specs.api.BambooSpec;
import com.atlassian.bamboo.specs.api.builders.BambooKey;
import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.applink.ApplicationLink;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.docker.DockerConfiguration;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.permission.PlanPermissions;
import com.atlassian.bamboo.specs.api.builders.plan.Job;
import com.atlassian.bamboo.specs.api.builders.plan.Plan;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.plan.Stage;
import com.atlassian.bamboo.specs.api.builders.plan.artifact.Artifact;
import com.atlassian.bamboo.specs.api.builders.plan.branches.BranchCleanup;
import com.atlassian.bamboo.specs.api.builders.plan.branches.PlanBranchManagement;
import com.atlassian.bamboo.specs.api.builders.plan.configuration.ConcurrentBuilds;
import com.atlassian.bamboo.specs.api.builders.project.Project;
import com.atlassian.bamboo.specs.api.builders.repository.VcsChangeDetection;
import com.atlassian.bamboo.specs.api.builders.requirement.Requirement;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.repository.bitbucket.server.BitbucketServerRepository;
import com.atlassian.bamboo.specs.builders.repository.viewer.BitbucketServerRepositoryViewer;
import com.atlassian.bamboo.specs.builders.trigger.BitbucketServerTrigger;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.usfoods.bamboo.spec.config.Configuration;
import com.usfoods.bamboo.spec.config.PlanPropertyConfig;
import com.usfoods.bamboo.spec.config.ProjectPropertyConfig;
import com.usfoods.bamboo.spec.config.RepoPropertyConfig;
import com.usfoods.bamboo.spec.config.UploadEnvVariableJobPropertyConfig;
import com.usfoods.bamboo.spec.config.UploadParameterFileJobPropertyConfig;
import com.usfoods.bamboo.spec.config.UploadTemplateJobPropertyConfig;
import com.usfoods.bamboo.spec.config.VariableConfig;
import com.usfoods.bamboo.spec.constant.Constant.TaskClass;
import com.usfoods.bamboo.spec.factory.TaskFactory;
import com.usfoods.bamboo.spec.util.Util;

public class StandardLambdaBuildPlanSpec {
	
	public static String propertyFileName = "standard-lambda-project.properties"; //have to override this
	public static String downloadBuildNumberArtifactTaskProperty = "artifact-download-task-build-version.properties";
	public static ProjectPropertyConfig projectProp;
	public static PlanPropertyConfig planProp;
	public static RepoPropertyConfig repoProperty;
	public static UploadEnvVariableJobPropertyConfig uploadEnvVariableJobProperty;
	public static UploadTemplateJobPropertyConfig uploadTemplateProperty;
	public static UploadParameterFileJobPropertyConfig initUploadParaFiles;
	public static VariableConfig variableConfig;
	
	public static Task pinAWSAgentTask;
	public static Task sourceCheckoutTask;
	public static Task uploadS3EnvVarTask;
	public static Task uploadS3ParameterTask;
	public static Task uploadS3RootTemplateTask;
	
	public static Task downloadBuildVersionTask;
	public static Task replaceBuildNumberTask;
	
	public static String pipelineVersion;
	public static List<Variable> variableList = new ArrayList<Variable>();
		
	public static void init(){
		try {
			pipelineVersion = Util.getPipelineVersion();
			variableList = Util.mavenPropertyReader();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	
		//new way to get the task
		try {
			
			pinAWSAgentTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.PIN_AWS_AGENT_TASK);
			sourceCheckoutTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.SOURCE_CHECKOUT_TASK);
			uploadS3EnvVarTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.UPLOAD_S3_ENV_VAR_TASK);
			uploadS3ParameterTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.UPLOAD_S3_PARA_TASK);
			uploadS3RootTemplateTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.UPLOAD_S3_ROOT_TEMPLATE_TASK);
			downloadBuildVersionTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, downloadBuildNumberArtifactTaskProperty);
			replaceBuildNumberTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.SCRIPT_TASK, "script-task-replace-build-number.properties");
			
			projectProp = Configuration.initConfigOfProjectProperty(propertyFileName);
			planProp = Configuration.initConfigOfPlanProperty(propertyFileName);
			repoProperty = Configuration.initRepoPropertyConfig(propertyFileName);
			uploadEnvVariableJobProperty = Configuration.initUploadEnvVariableJobPropertyConfig(propertyFileName);
			initUploadParaFiles = Configuration.initUploadParameterFileJobPropertyConfig(propertyFileName);
			uploadTemplateProperty = Configuration.initUploadTemplateJobPropertyConfig(propertyFileName);
			variableConfig = Configuration.initVariableConfig(propertyFileName);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}
    
    public Plan plan() {
    	
    	//check logic
    	String[] envArr = projectProp.getProjectEnv().split("\\|");
    	List<String> envList = Arrays.asList(envArr);
    	List<Artifact> uploadEnvVariableArtifactList = new ArrayList<Artifact>();
    	List<Artifact> uploadParaFilesArtifactList = new ArrayList<Artifact>();
    	
    	if(envList.contains("DEV")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameDev())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternDev())
                    .shared(uploadEnvVariableJobProperty.getSharableDev());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameDev())
                    .copyPattern(initUploadParaFiles.getCopyPatternDev())
                    .shared(initUploadParaFiles.getSharableDev());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    		
    		
    	}
    	
    	if(envList.contains("QA")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameQa())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternQa())
                    .shared(uploadEnvVariableJobProperty.getSharableQa());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameQa())
                    .copyPattern(initUploadParaFiles.getCopyPatternQa())
                    .shared(initUploadParaFiles.getSharableQa());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	if(envList.contains("SIT")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameSit())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternSit())
                    .shared(uploadEnvVariableJobProperty.getSharableSit());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameSit())
                    .copyPattern(initUploadParaFiles.getCopyPatternSit())
                    .shared(initUploadParaFiles.getSharableSit());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	if(envList.contains("UAT")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameUat())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternUat())
                    .shared(uploadEnvVariableJobProperty.getSharableUat());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameUat())
                    .copyPattern(initUploadParaFiles.getCopyPatternUat())
                    .shared(initUploadParaFiles.getSharableUat());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	if(envList.contains("PERF")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNamePerf())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternPerf())
                    .shared(uploadEnvVariableJobProperty.getSharablePerf());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNamePerf())
                    .copyPattern(initUploadParaFiles.getCopyPatternPerf())
                    .shared(initUploadParaFiles.getSharablePerf());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	if(envList.contains("NONPROD")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameNonprod())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternNonprod())
                    .shared(uploadEnvVariableJobProperty.getSharableNonprod());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameNonprod())
                    .copyPattern(initUploadParaFiles.getCopyPatternNonprod())
                    .shared(initUploadParaFiles.getSharableNonprod());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	if(envList.contains("PROD")){
    		Artifact uploadEnvVariableartifact = new Artifact()
                    .name(uploadEnvVariableJobProperty.getArtifactNameProd())
                    .copyPattern(uploadEnvVariableJobProperty.getCopyPatternProd())
                    .shared(uploadEnvVariableJobProperty.getSharableProd());
    		
    		Artifact uploadParaFilesartifact = new Artifact()
                    .name(initUploadParaFiles.getArtifactNameProd())
                    .copyPattern(initUploadParaFiles.getCopyPatternProd())
                    .shared(initUploadParaFiles.getSharableProd());
    		
    		uploadEnvVariableArtifactList.add(uploadEnvVariableartifact);
    		uploadParaFilesArtifactList.add(uploadParaFilesartifact);
    	}
    	
    	
    	//Environment[] environmentArr = environmentList.toArray(new Environment[environmentList.size()]);
    	Artifact[] uploadEnvVariableArtifactArr = uploadEnvVariableArtifactList.toArray(new Artifact[uploadEnvVariableArtifactList.size()]);
    	Artifact[] uploadParaFilesArtifactArr  = uploadParaFilesArtifactList.toArray(new Artifact[uploadParaFilesArtifactList.size()]);
    	
        final Plan plan = new Plan(new Project()
                .key(new BambooKey(projectProp.getBambooKey()))
                .name(projectProp.getBambooName())
                .description(projectProp.getBambooDescription()),
            planProp.getBambooName(),
            planProp.getBambooKey())
            .pluginConfigurations(new ConcurrentBuilds()
                    .useSystemWideDefault(false))
            .stages(new Stage("Default Stage")
                    .jobs(new Job(uploadEnvVariableJobProperty.getJobName(),
                            new BambooKey(uploadEnvVariableJobProperty.getJobKey()))
                            .artifacts(
                            		uploadEnvVariableArtifactArr
                            		)
                            .tasks(pinAWSAgentTask,
                            		sourceCheckoutTask,
                            		uploadS3EnvVarTask),
                        new Job(initUploadParaFiles.getJobName(),
                                new BambooKey(initUploadParaFiles.getJobKey()))
                                .artifacts(
                                		uploadParaFilesArtifactArr
                                		)
                                .tasks(pinAWSAgentTask,
                                		sourceCheckoutTask,
                                		downloadBuildVersionTask,
                                		replaceBuildNumberTask,
                                		uploadS3ParameterTask
                                		)
                                .requirements(new Requirement("aws_bamboo_agent"))
                                .dockerConfiguration(new DockerConfiguration()
                                        .enabled(false)),    
                        new Job(uploadTemplateProperty.getJobName(),
                            new BambooKey(uploadTemplateProperty.getJobKey()))
                            .tasks(pinAWSAgentTask,
                            		sourceCheckoutTask,
                            		uploadS3RootTemplateTask
                                )
                            .requirements(new Requirement("aws_bamboo_agent"))))
            .planRepositories(new BitbucketServerRepository()
                    .name(repoProperty.getRepoName())
                    .repositoryViewer(new BitbucketServerRepositoryViewer())
                    .server(new ApplicationLink()
                            .name(repoProperty.getRepoServerName())
                            .id(repoProperty.getRepoServerId()))
                    .projectKey(repoProperty.getProjectKey())
                    .repositorySlug(repoProperty.getRepositorySlug())
                    .sshPublicKey(repoProperty.getSshPublicKey())
                    .sshPrivateKey(repoProperty.getSshPrivateKey())
                    .sshCloneUrl(repoProperty.getSshCloneUrl())
                    .changeDetection(new VcsChangeDetection()))
            
            .triggers(new BitbucketServerTrigger()
                    .description(repoProperty.getRepoName() + "-trigger"))
            
            .variables(new Variable(variableConfig.getKey1(),
            		variableConfig.getValue1()),
                new Variable(variableConfig.getKey2(),
                		variableConfig.getValue2()),
                new Variable(variableConfig.getKey3(),
                		variableConfig.getValue3()),
                new Variable(variableConfig.getKey4(),
                		variableConfig.getValue4()),
                new Variable(variableConfig.getKey5(),
                		variableConfig.getValue5()),
                new Variable("bamboo.pipeline.version", pipelineVersion)
            		).variables(variableList.toArray(new Variable[variableList.size()]))
            .planBranchManagement(new PlanBranchManagement()
                    .delete(new BranchCleanup())
                    .notificationForCommitters());
        return plan;
    }
    
    public static void main(String... argv) {
        //By default credentials are read from the '.credentials' file.
    	init();
    	BambooServer bambooServer = new BambooServer(projectProp.getBambooHostname());
        final StandardLambdaBuildPlanSpec planSpec = new StandardLambdaBuildPlanSpec();
        
        final Plan plan = planSpec.plan();
        bambooServer.publish(plan);
        
    }
}