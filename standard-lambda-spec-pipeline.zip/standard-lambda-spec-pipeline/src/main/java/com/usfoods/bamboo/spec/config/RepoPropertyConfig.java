package com.usfoods.bamboo.spec.config;

public class RepoPropertyConfig {
    
	private String repoName;
	
    private String repoServerName;
	
    private String repoServerId;
	
    private String projectKey;
	
    private String repositorySlug;
	
    private String sshPublicKey;
	
    private String sshPrivateKey;
	
    private String sshCloneUrl;
    
    public RepoPropertyConfig repoPropertyConfig(){
    	RepoPropertyConfig repoPropertyConfig = new RepoPropertyConfig();
		return repoPropertyConfig;
    }


	public String getRepoName() {
		return repoName;
	}

	public String getRepoServerName() {
		return repoServerName;
	}


	public String getRepoServerId() {
		return repoServerId;
	}


	public String getProjectKey() {
		return projectKey;
	}


	public String getRepositorySlug() {
		return repositorySlug;
	}


	public String getSshPublicKey() {
		return sshPublicKey;
	}


	public String getSshPrivateKey() {
		return sshPrivateKey;
	}


	public String getSshCloneUrl() {
		return sshCloneUrl;
	}


	public void setRepoName(String repoName) {
		this.repoName = repoName;
	}


	public void setRepoServerName(String repoServerName) {
		this.repoServerName = repoServerName;
	}


	public void setRepoServerId(String repoServerId) {
		this.repoServerId = repoServerId;
	}


	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}


	public void setRepositorySlug(String repositorySlug) {
		this.repositorySlug = repositorySlug;
	}


	public void setSshPublicKey(String sshPublicKey) {
		this.sshPublicKey = sshPublicKey;
	}


	public void setSshPrivateKey(String sshPrivateKey) {
		this.sshPrivateKey = sshPrivateKey;
	}


	public void setSshCloneUrl(String sshCloneUrl) {
		this.sshCloneUrl = sshCloneUrl;
	}
    
	
    
    
    
}
