package com.usfoods.bamboo.spec.standard.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.deployment.Deployment;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.deployment.ReleaseNaming;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.CleanWorkingDirectoryTask;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.usfoods.bamboo.spec.config.Configuration;
import com.usfoods.bamboo.spec.config.PlanPropertyConfig;
import com.usfoods.bamboo.spec.config.ProjectPropertyConfig;
import com.usfoods.bamboo.spec.config.VariableConfig;
import com.usfoods.bamboo.spec.constant.Constant.TaskClass;
import com.usfoods.bamboo.spec.factory.TaskFactory;
import com.usfoods.bamboo.spec.util.Util;


public class StandardLambdaCreateStackDeploymentSpec {
	
	public static String propertyFileName = "standard-lambda-project.properties";
	public static String variableConfigFileName = "standard-lambda-deployment-variable.properties";
	public static String envKey = "createstack";
	public static ProjectPropertyConfig projectProp;
	public static PlanPropertyConfig planProp;
	public static Task pinAWSAgentTask;
	public static Task awsCredentialsVariablesTask;
	
	//dev environment
	public static Task artifactDownloadTaskParaDev;
	public static Task artifactDownloadTaskEnvDev;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskDev;
	public static Task enableTeminatorProtectionTaskDev;
	public static Task awsCloudformationStackCreateStackTaskDev;
	
	//nonprod environment
	public static Task artifactDownloadTaskParaNonprod;
	public static Task artifactDownloadTaskEnvNonProd;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskNonProd;
	public static Task enableTeminatorProtectionTaskNonprod;
	public static Task awsCloudformationStackCreateStackTaskNonprod;
	
	//sit environment
	public static Task artifactDownloadTaskParaSit;
	public static Task artifactDownloadTaskEnvSit;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskSit;
	public static Task enableTeminatorProtectionTaskSit;
	public static Task awsCloudformationStackCreateStackTaskSit;
	
	//qa environment
	public static Task artifactDownloadTaskParaQa;
	public static Task artifactDownloadTaskEnvQa;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskQa;
	public static Task enableTeminatorProtectionTaskQa;
	public static Task awsCloudformationStackCreateStackTaskQa;
	
	//uat environment
	public static Task artifactDownloadTaskParaUat;
	public static Task artifactDownloadTaskEnvUat;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskUat;
	public static Task enableTeminatorProtectionTaskUat;
	public static Task awsCloudformationStackCreateStackTaskUat;
	
	//perf environment
	public static Task artifactDownloadTaskParaPerf;
	public static Task artifactDownloadTaskEnvPerf;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskPerf;
	public static Task enableTeminatorProtectionTaskPerf;
	public static Task awsCloudformationStackCreateStackTaskPerf;
	
	//prod environment
	public static Task artifactDownloadTaskParaProd;
	public static Task artifactDownloadTaskEnvProd;
	public static Task awsLambdaFunctionUpdateEnvironmentVariablesTaskProd;
	public static Task enableTeminatorProtectionTaskProd;
	public static Task awsCloudformationStackCreateStackTaskProd;
	
	//share with all environment
	public static Task cleanWorkingDirectoryTask;
	public static Task awsCloudformationStackValidateRootTemplateTask;


	public static String deploymentProjectName;
	public static VariableConfig variableConfig;
	
	public static void init(){

		try {
	    		projectProp = Configuration.initConfigOfProjectProperty(propertyFileName);
				planProp = Configuration.initConfigOfPlanProperty(propertyFileName);
				variableConfig = Configuration.initVariableConfig(variableConfigFileName);
				deploymentProjectName = projectProp.getRootName() + "-createstack";
				{//share with all environment
					pinAWSAgentTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.PIN_AWS_AGENT_TASK);
					awsCredentialsVariablesTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CREDENTIALS_VARIABLES_TASK);
					awsCloudformationStackValidateRootTemplateTask = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_VALIDATE_ROOT_TEMPLATE_TASK);
					cleanWorkingDirectoryTask = new CleanWorkingDirectoryTask();
				}
				
				{//dev environment
					artifactDownloadTaskParaDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-dev.properties");
					artifactDownloadTaskEnvDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-dev.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-dev.properties");
					enableTeminatorProtectionTaskDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-dev.properties");
					awsCloudformationStackCreateStackTaskDev = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-dev.properties");
				}
				{//sit environment
					artifactDownloadTaskParaSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-sit.properties");
					artifactDownloadTaskEnvSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-sit.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-sit.properties");
					enableTeminatorProtectionTaskSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-sit.properties");
					awsCloudformationStackCreateStackTaskSit = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-sit.properties");
				}
				{//qa environment
					artifactDownloadTaskParaQa = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-qa.properties");
					artifactDownloadTaskEnvQa = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-qa.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskQa = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-qa.properties");
					enableTeminatorProtectionTaskQa = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-qa.properties");
					awsCloudformationStackCreateStackTaskQa = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-qa.properties");
				}
				{//uat environment
					artifactDownloadTaskParaUat = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-uat.properties");
					artifactDownloadTaskEnvUat = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-uat.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskUat = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-uat.properties");
					enableTeminatorProtectionTaskUat = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-uat.properties");
					awsCloudformationStackCreateStackTaskUat = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-uat.properties");
				}
				{//perf environment
					artifactDownloadTaskParaPerf = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-perf.properties");
					artifactDownloadTaskEnvPerf = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-perf.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskPerf = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-perf.properties");
					enableTeminatorProtectionTaskPerf = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-perf.properties");
					awsCloudformationStackCreateStackTaskPerf = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-perf.properties");
				}
				
				//nonprod environment
				{
					artifactDownloadTaskParaNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-nonprod.properties");
					artifactDownloadTaskEnvNonProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-nonprod.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskNonProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-nonprod.properties");
					enableTeminatorProtectionTaskNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-nonprod.properties");
					awsCloudformationStackCreateStackTaskNonprod = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-nonprod.properties");
				}
				
				//prod environment
				{
					artifactDownloadTaskParaProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-para-prod.properties");
					artifactDownloadTaskEnvProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ARTIFACT_DOWNLOAD_TASK, "artifact-download-task-env-prod.properties");
					awsLambdaFunctionUpdateEnvironmentVariablesTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_LAMBDA_FUNCTION_UPDATE_ENV_VARIABLES_TASK, "aws-lambda-function-update-environment-variables-prod.properties");
					enableTeminatorProtectionTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.ENABLE_TEMINATOR_PROTECTION_TASK, "script-task-enable-termination-protection-prod.properties");
					awsCloudformationStackCreateStackTaskProd = TaskFactory.generateTaskFromExistingTaskWarehouse(TaskClass.AWS_CLOUDFORMATION_STACK_CREATE_STACK_TASK, "aws-cloudformation-configuration-task-create-stack-prod.properties");
				}

		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	
	}
    
    public Deployment rootObject() {
    	
    	//get Env
    	String[] envArr = projectProp.getProjectEnv().split("\\|");
    	List<String> envList = Arrays.asList(envArr);
    	List<Environment> environmentList = new ArrayList<Environment>();
    	//if dev exits
    	//create DEV environment object
    	if(envList.contains("DEV")){
    		Environment env = new Environment("dev")
	          .tasks(
	          		cleanWorkingDirectoryTask,
	          		artifactDownloadTaskParaDev,
	          		pinAWSAgentTask,
	          		awsCloudformationStackValidateRootTemplateTask,
	          		awsCloudformationStackCreateStackTaskDev,
	          		awsCredentialsVariablesTask,
	          		enableTeminatorProtectionTaskDev,
	          		artifactDownloadTaskEnvDev,
	          		awsLambdaFunctionUpdateEnvironmentVariablesTaskDev)
	          .variables(new Variable(variableConfig.getKey1(),
	          		variableConfig.getValue1() + "_dev"));
    		environmentList.add(env);
    	}
    	
    	//if qa exists
    	//create qa environment object
    	if(envList.contains("QA")){
    		Environment env = new Environment("qa")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaQa,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskQa,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskQa,
    		          		artifactDownloadTaskEnvQa,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskQa)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_qa"));
    		environmentList.add(env);
    	}
    	
    	//if sit exists
    	//create sit environment object
    	if(envList.contains("SIT")){
    		Environment env = new Environment("sit")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaSit,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskSit,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskSit,
    		          		artifactDownloadTaskEnvSit,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskSit)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_sit"));
    		environmentList.add(env);
    	}
    	
    	//if uat exists
    	//create uat environment object
    	if(envList.contains("UAT")){
    		Environment env = new Environment("uat")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaUat,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskUat,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskUat,
    		          		artifactDownloadTaskEnvUat,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskUat)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_uat"));
    		environmentList.add(env);
    	}
    	
    	//if perf exists
    	//create perf environment object
    	if(envList.contains("PERF")){
    		Environment env = new Environment("perf")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaPerf,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskPerf,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskPerf,
    		          		artifactDownloadTaskEnvPerf,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskPerf)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_perf"));
    		environmentList.add(env);
    	}
    	
    	//if nonprod exists
    	//create nonprod environment object
    	if(envList.contains("NONPROD")){
    		Environment env = new Environment("nonprod")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaNonprod,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskNonprod,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskNonprod,
    		          		artifactDownloadTaskEnvNonProd,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskNonProd)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_nonprod"));
    		environmentList.add(env);
    	}
    	
    	//if prod exists
    	//create prod environment object
    	if(envList.contains("PROD")){
    		Environment env = new Environment("prod")
    		          .tasks(
    		          		cleanWorkingDirectoryTask,
    		          		artifactDownloadTaskParaProd,
    		          		pinAWSAgentTask,
    		          		awsCloudformationStackValidateRootTemplateTask,
    		          		awsCloudformationStackCreateStackTaskProd,
    		          		awsCredentialsVariablesTask,
    		          		enableTeminatorProtectionTaskProd,
    		          		artifactDownloadTaskEnvProd,
    		          		awsLambdaFunctionUpdateEnvironmentVariablesTaskProd)
    		          .variables(new Variable(variableConfig.getKey1(),
    		          		variableConfig.getValue1() + "_prod"));
    		environmentList.add(env);
    	}
    	//create Environment List
    	Environment[] environmentArr = environmentList.toArray(new Environment[environmentList.size()]);
    	//.environments(EnvironmentList)
    	final Deployment rootObject = new Deployment(new PlanIdentifier(projectProp.getBambooKey(), planProp.getBambooKey()),
        		deploymentProjectName)
              .releaseNaming(new ReleaseNaming("release-1")
              .autoIncrement(true))
              .environments(environmentArr);
    
        return rootObject;
    }
     
    public DeploymentPermissions deploymentPermission() {
    	
    	final DeploymentPermissions deploymentPermission = Util.getDeploymentPermission(variableConfigFileName, envKey, deploymentProjectName);
    	
        return deploymentPermission;
    }
    
    public EnvironmentPermissions environmentPermissionDev() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "dev", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionSit() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "sit", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionQa() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "qa", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionUat() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "uat", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionPerf() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "perf", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionNonProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "nonprod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public EnvironmentPermissions environmentPermissionProd() {
    	
    	final EnvironmentPermissions environmentPermission1 = Util.getEnvironmentPermission(variableConfigFileName, envKey, "prod", deploymentProjectName);
        return environmentPermission1;
    }
    
    public static void main(String... argv) {
        //By default credentials are read from the '.credentials' file.
    	init();
    	BambooServer bambooServer = new BambooServer(projectProp.getBambooHostname());
        final StandardLambdaCreateStackDeploymentSpec planSpec = new StandardLambdaCreateStackDeploymentSpec();
        
        final Deployment rootObject = planSpec.rootObject();
        bambooServer.publish(rootObject);
        
        final DeploymentPermissions deploymentPermission = planSpec.deploymentPermission();
        bambooServer.publish(deploymentPermission);
        
        final EnvironmentPermissions environmentPermission1 = planSpec.environmentPermissionDev();
        bambooServer.publish(environmentPermission1);
        
        final EnvironmentPermissions environmentPermission2 = planSpec.environmentPermissionSit();
        bambooServer.publish(environmentPermission2);
    }
}